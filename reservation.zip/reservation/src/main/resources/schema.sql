
CREATE TABLE register (
  id INTEGER(11) AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(40),
  email VARCHAR(50),
  date_of_birth DATE,
  phone_num VARCHAR(40),
  id_proof VARCHAR(40),
  id_proof_no VARCHAR(40),
  user_passwd VARCHAR(40)
);