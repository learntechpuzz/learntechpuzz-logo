package com.capone.hotelreservation.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class HotelReservationSecurityInitializer extends AbstractSecurityWebApplicationInitializer {

}
