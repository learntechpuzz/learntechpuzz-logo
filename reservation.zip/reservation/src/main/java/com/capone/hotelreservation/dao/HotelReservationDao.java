package com.capone.hotelreservation.dao;

import java.sql.Types;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.capone.hotelreservation.model.Registration;

@Service
public class HotelReservationDao {
	
	@Autowired JdbcTemplate jdbcTemplate;

	
	 private static final String addRegistration =
			 
			  "INSERT INTO register (" +
			 
			  " name, " +
			 
			  " email, " +
			 
			  " date_of_birth, " +
			  
			  " phone_num, " +
			 
			  " id_proof, " +
			  
			  " id_proof_no, " +
			 
			  " user_passwd) " +
			 
			  "VALUES (?, ?, ?, ?, ?, ?, ?)";
	 
	 private static final String getRegistartion = "SELECT * FROM REGISTER"; 

	public void addRegistration(Registration registration) {
		
        Object[] params = new Object[] { registration.getName(), registration.getMailid(), registration.getDob(), registration.getPhoneNum(),
        		registration.getIdProof(), registration.getIdProofNo(), registration.getPassword()};
         
        int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
	

		int row = jdbcTemplate.update(addRegistration, params, types );
		System.out.println("No of Rows updated" + row);
		
	}

	public List<Registration> getSignUpData() {
		return jdbcTemplate.query(getRegistartion, new RegstrationMapper());
		
	}
	
	

}
