package com.capone.hotelreservation.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capone.hotelreservation.model.DeluxeAC;
import com.capone.hotelreservation.model.DeluxeNonAC;
import com.capone.hotelreservation.model.PremierSuite;

@Controller
public class RoomBookingController {
	
	@ModelAttribute("deluxeNonAC")
	public DeluxeNonAC modelDeluxeNonAc() {
		return new DeluxeNonAC();
	}
	
	@ModelAttribute("deluxeAC")
	public DeluxeAC modelDeluxeAc() {
		return new DeluxeAC();
	}
	
	@ModelAttribute("premierSuite")
	public PremierSuite modelPremierSuite() {
		return new PremierSuite();
	}
	
	@RequestMapping(value = "/DeluxeNonAC", method = RequestMethod.GET)
	public ModelAndView deluxeNonAc() {
		ModelAndView model = new ModelAndView();
		model.setViewName("deluxeNonAC");
		return model;
	}
	

	@RequestMapping(value = "/DeluxeAC", method = RequestMethod.GET)
	public ModelAndView deluxeAc() {
		ModelAndView model = new ModelAndView();
		model.setViewName("deluxeAC");
		return model;
	}
	

	@RequestMapping(value = "/PremierSuite", method = RequestMethod.GET)
	public ModelAndView premierSute() {
		ModelAndView model = new ModelAndView();
		model.setViewName("premierSuite");
		return model;
	}
	
	@RequestMapping(value = "/DeluxeNonAC", method = RequestMethod.POST)
	public ModelAndView bookDeluxeNonAc(@Valid @ModelAttribute("deluxeNonAC") DeluxeNonAC deluxeNonAC, BindingResult error) {
		
		ModelAndView model = new ModelAndView();
		
		if (error.hasErrors()) {
			model.setViewName("deluxeNonAC");
			model.addObject("bookError", "Invalid Data");
			
		} if (!error.hasErrors()) {
			model.setViewName("redirect:bookingsuccess");
		}
		
		return model;
	}
	
	@RequestMapping(value = "/DeluxeAC", method = RequestMethod.POST)
	public ModelAndView bookDeluxeAc(@Valid @ModelAttribute("deluxeAC") DeluxeAC deluxeAC, BindingResult error) {
		
		ModelAndView model = new ModelAndView();
		
		if (error.hasErrors()) {
			model.setViewName("deluxeAC");
			model.addObject("bookError", "Invalid Data");
			
		} if (!error.hasErrors()) {
			model.setViewName("redirect:bookingsuccess");	
		}
		
		return model;
	}
	
	@RequestMapping(value = "/PremierSuite", method = RequestMethod.POST)
	public ModelAndView bookPremierSuite(@Valid @ModelAttribute("premierSuite") PremierSuite premierSuite, BindingResult error) {
		
		ModelAndView model = new ModelAndView();
		
		if (error.hasErrors() || (premierSuite.getFromDate().equalsIgnoreCase("25-11-2019") 
				&& premierSuite.getToDate().equalsIgnoreCase("22-11-2019"))) {
			model.setViewName("premierSuite");
			model.addObject("bookError", "Invalid Data");
			
		} if (!error.hasErrors()) {
			model.setViewName("redirect:bookingsuccess");
		}
		return model;
	}
	
	@RequestMapping(value = "/bookingsuccess", method = RequestMethod.GET)
	public ModelAndView bookingSuccess() {
		ModelAndView model = new ModelAndView();
		model.setViewName("bookingSuccess");
		return model;
	}

}
