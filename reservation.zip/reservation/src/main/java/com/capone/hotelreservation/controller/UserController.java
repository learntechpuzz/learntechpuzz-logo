package com.capone.hotelreservation.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.capone.hotelreservation.model.User;

@Controller
@SessionAttributes("/user")
public class UserController {

	@ModelAttribute("user")
	public User user() {
		return new User();
	}
	
	@RequestMapping(value = "/userlogin", method = RequestMethod.GET)
	public ModelAndView loginPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("userlogin");
		return model;
	}
	
	@RequestMapping(value = "/userlogin", method = RequestMethod.POST)
	public ModelAndView userLogin(@Valid @ModelAttribute("user") User user, BindingResult error) {
		
		ModelAndView model = new ModelAndView();
		
		if (error.hasErrors() || (!user.getEmail().equalsIgnoreCase("sam.watson@gmail.com"))
				|| (!user.getPassword().equalsIgnoreCase("sam12345"))) {
			model.setViewName("userlogin");
			model.addObject("userError", "Invalid Credentials");
			return model;
		}
		
		model.setViewName("redirect:DeluxeNonAC");
		return model;
	}
	
	
}
