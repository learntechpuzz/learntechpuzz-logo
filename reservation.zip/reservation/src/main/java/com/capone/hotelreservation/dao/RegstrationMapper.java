package com.capone.hotelreservation.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.capone.hotelreservation.model.Registration;

public class RegstrationMapper implements RowMapper<Registration> {

	public Registration mapRow(ResultSet rs, int rowNum) throws SQLException {
		Registration registration = new Registration();
		registration.setName(rs.getString("name"));
		registration.setMailid(rs.getString("email"));
		registration.setDob(rs.getDate("date_of_birth"));
		registration.setPhoneNum(rs.getString("phone_num"));
		registration.setIdProof(rs.getString("id_proof"));
		registration.setIdProofNo(rs.getString("id_proof_no"));
		return registration;
	}

}
