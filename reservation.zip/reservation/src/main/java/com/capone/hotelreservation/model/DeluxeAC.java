package com.capone.hotelreservation.model;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class DeluxeAC {
	
	@NotEmpty(message =  "Please provide extra bed details, if not required make it 0")
	@Size(min=1, max=1, message = "Max 1 digit allowed")
	public String extraBeds;
	
	@NotEmpty (message = "Please provide from date")
	public String fromDate;
	
	@NotEmpty (message = "Please provide to date")
	public String toDate;
	
	public String amount;

	public String getExtraBeds() {
		return extraBeds;
	}

	public void setExtraBeds(String extraBeds) {
		this.extraBeds = extraBeds;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	

}
