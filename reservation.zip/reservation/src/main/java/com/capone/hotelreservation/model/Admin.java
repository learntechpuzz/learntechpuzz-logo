package com.capone.hotelreservation.model;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class Admin {
	
	@NotEmpty(message = "Please enter user name")
	@Size(max=40, message = "Your name must not exceed 40 characters")
	@Email(message = "must be email address")
	public String email;
	
	@NotEmpty(message = "Please enter your password")
	@Size(min=8, message = "Minimum of 8 characters length")
	public String password;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}
