package com.capone.hotelreservation.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.capone.hotelreservation.dao.HotelReservationDao;
import com.capone.hotelreservation.model.Admin;
import com.capone.hotelreservation.model.Registration;

@Controller
@SessionAttributes("/register")
public class RegisterController {
	
	@Autowired
	HotelReservationDao hotelDao;
	

	String regex = "^[a-zA-Z]+$";
	
	
	@ModelAttribute("admin") 
	public Admin admin() {
		return new Admin();
	}
	
	@ModelAttribute("register")
	public Registration register() {
		return new Registration();
	}
	
	@ModelAttribute("idProofList")
	   public Map<String, String> getCountryList() {
	      Map<String, String> idProofList = new HashMap<String, String>();
	      idProofList.put("PAN", "PAN CARD");
	      idProofList.put("VI", "Voter Id");
	      idProofList.put("PP", "Passport");
	      idProofList.put("LCE", "Licence");
	      idProofList.put("ARC", "Aadhar card");
	      return idProofList;
	   }
	
	@RequestMapping(value = { "/signup"}, method = RequestMethod.GET)
	public ModelAndView signUp() {
		ModelAndView model = new ModelAndView();
		model.setViewName("signUp");
		return model;
	}
	
	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public ModelAndView registerUser(@Valid @ModelAttribute("register") Registration registration, BindingResult error) {
		
		ModelAndView model = new ModelAndView();
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(registration.getName());
	
		if (error.hasErrors() || registration.getIdProof().equalsIgnoreCase("") || !matcher.matches()) {
			model.setViewName("signUp");
			model.addObject("signError", "Invalid Data");
			return model;
		}
		hotelDao.addRegistration(registration);
		model.setViewName("redirect:DeluxeNonAC");
		return model;
	}
	
	@RequestMapping(value = { "/success"}, method = RequestMethod.GET)
	public ModelAndView success() {
		ModelAndView model = new ModelAndView();
		model.setViewName("success");
		return model;
	}
	
	@RequestMapping(value = "/adminlogin", method = RequestMethod.GET)
	public ModelAndView adminLogin() {
		ModelAndView model = new ModelAndView();
		model.setViewName("adminlogin");
		return model;
	}
	
	@RequestMapping(value = { "/adminlogin"}, method = RequestMethod.POST)
	public String adminSuccess(@Valid @ModelAttribute("admin") Admin admin, BindingResult error, Model model) {
		
		boolean sigleList = false;
		boolean doubleList = false;
		
		if (error.hasErrors() || (!admin.getEmail().equalsIgnoreCase("admin@mymail.com"))
				|| (!admin.getPassword().equalsIgnoreCase("admin1234"))) {
			model.addAttribute("adminError", "Invalid Credentials");
			return "adminlogin";
		}
		
		List<Registration> registrationsList = hotelDao.getSignUpData();
		if(registrationsList.size() > 0 ) {
			sigleList = true;
			model.addAttribute("sigleList", sigleList);
			model.addAttribute("registrationsList", registrationsList);
		}
		if(registrationsList.size() == 2 ) {
			doubleList = true;
			model.addAttribute("doubleList", doubleList);
			model.addAttribute("registrationsList", registrationsList);
		}
		
		return "bookingdetails";
		 
	}
	
	@RequestMapping(value = "/bookingdetails", method = RequestMethod.GET)
	public ModelAndView adminRedirect1() {
		ModelAndView model = new ModelAndView();
		model.setViewName("bookingdetails");
		return model;
	}
	
}
