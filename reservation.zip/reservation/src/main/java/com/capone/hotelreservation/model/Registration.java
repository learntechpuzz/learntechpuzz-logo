package com.capone.hotelreservation.model;

import java.sql.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.NumberFormat;

public class Registration {
	
	@NotEmpty(message = "Please enter name")
	@Size(max=40, message = "Your name must not exceed 40 characters")
	public String name;
	
	@NotEmpty(message = "Please enter valid mail id")
	@Email(message = "Must be valid email address")
	public String mailid;
	
	@NotNull(message = "Please enter date of birth must be YYYY-MM-DD format")
	public Date dob;
	
	@NotEmpty(message = "Please enter phone number")
	@Size(min=10, max=10, message = "Your phone number must be 10 digits")
	@Pattern(regexp="(^[0-9]{10})", message = "Must be numbers")
	public String phoneNum;
	
	@NotEmpty(message = "Please select id proof type")
	@NumberFormat
	public String idProof;
	
	@NotEmpty(message = "Please enter id proof number")
	public String idProofNo;
	
	@NotEmpty(message = "Please enter password")
	public String password;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getIdProof() {
		return idProof;
	}
	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}
	public String getIdProofNo() {
		return idProofNo;
	}
	public void setIdProofNo(String idProofNo) {
		this.idProofNo = idProofNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}


}
